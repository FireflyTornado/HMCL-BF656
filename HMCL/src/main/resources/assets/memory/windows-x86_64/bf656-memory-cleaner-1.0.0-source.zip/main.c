/* SPDX-License-Identifier: GPL-3.0-only */
#include "cleaner.h"
#include <stdio.h>
#include <string.h>

/* Output may only target stdout or this component's local named-pipe namespace.
 * There is deliberately no elevated arbitrary-file-write option. */
static HANDLE connect_result_pipe(const wchar_t *path)
{
    HANDLE pipe;
    if (!WaitNamedPipeW(path, 5000)) return INVALID_HANDLE_VALUE;
    pipe = CreateFileW(path, GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (pipe != INVALID_HANDLE_VALUE && GetFileType(pipe) != FILE_TYPE_PIPE) {
        CloseHandle(pipe);
        SetLastError(ERROR_INVALID_HANDLE);
        return INVALID_HANDLE_VALUE;
    }
    return pipe;
}

int wmain(int argc, wchar_t **argv)
{
    BF656_REQUEST request;
    BF656_RESULT result = {0};
    HANDLE pipe = INVALID_HANDLE_VALUE;
    char json[8192];
    DWORD written = 0, code;
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    if (!bf656_parse(argc, argv, &request)) {
        result.error = ERROR_INVALID_PARAMETER;
    } else {
        if (request.pipe) {
            pipe = connect_result_pipe(request.pipe);
            if (pipe == INVALID_HANDLE_VALUE) {
                result.mode = request.mode;
                result.error = GetLastError();
                if (!result.error) result.error = ERROR_BROKEN_PIPE;
            }
        }
        /* Establish the requested result channel before any memory operations. */
        if (!result.error) bf656_run(&request, &result);
    }
    code = bf656_exit_code(&result);
    if (!bf656_json(&result, json, sizeof(json))) {
        if (pipe != INVALID_HANDLE_VALUE) CloseHandle(pipe);
        return ERROR_INSUFFICIENT_BUFFER;
    }
    if (pipe != INVALID_HANDLE_VALUE) {
        DWORD size = (DWORD)strlen(json);
        BOOL success = WriteFile(pipe, json, size, &written, NULL);
        CloseHandle(pipe);
        if (!success || written != size) return ERROR_WRITE_FAULT;
    } else {
        fputs(json, stdout);
    }
    return (int)code;
}
