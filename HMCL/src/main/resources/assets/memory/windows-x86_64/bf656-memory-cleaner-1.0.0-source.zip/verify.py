"""Exercise the real executable without issuing a successful cleanup request."""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import subprocess
import threading
import uuid

ROOT = Path(__file__).resolve().parent
EXE = ROOT / "out/x64/bf656-memory-cleaner.exe"
CASES: list[dict] = []


def invoke(arguments: list[str], expected_code: int = 0) -> dict:
    process = subprocess.run([str(EXE), *arguments], capture_output=True, text=True, timeout=12)
    assert process.returncode == expected_code, (arguments, process.returncode, process.stderr)
    result = json.loads(process.stdout)
    assert result["protocolVersion"] == 1
    assert result["exitCode"] == expected_code
    assert not result["cleanupExecuted"], result
    assert not any(item["attempted"] for item in result["operations"]), result
    CASES.append({"arguments": arguments, "exitCode": process.returncode, "status": result["status"]})
    return result


probe = invoke(["--probe"])
assert probe["status"] == "probe"
assert probe["requestedMask"] == 0
assert probe["profiles"] == {"safe": 7, "default": 231, "full": 255}
for profile, mask in probe["profiles"].items():
    dry = invoke(["--dry-run", "--profile", profile])
    assert dry["status"] == "dry_run" and dry["requestedMask"] == mask
    assert dry["availableBeforeBytes"] > 0 and dry["availableAfterBytes"] > 0
for arguments in [[], ["--unknown"], ["--probe", "--clean"],
                  ["--clean", "--profile", "typo"], ["--dry-run", "--profile"],
                  ["--dry-run", "--pipe", "C:\\result.json"]]:
    invoke(arguments, 87)

# This deliberately nonexistent pipe fails before the cleaning entry point.
missing = "\\\\.\\pipe\\hmcl-bf656-memory-" + str(uuid.uuid4())
invoke(["--clean", "--profile", "safe", "--pipe", missing], 2)

# Read-only probe confirms whether a direct cleanup request must reject elevation.
# Do not issue --clean at all when this test itself runs elevated.
if not probe["elevated"]:
    invoke(["--clean", "--profile", "safe"], 740)

kernel = ctypes.WinDLL("kernel32", use_last_error=True)
kernel.CreateNamedPipeW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                  wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                  wintypes.DWORD, ctypes.c_void_p]
kernel.CreateNamedPipeW.restype = wintypes.HANDLE
kernel.ConnectNamedPipe.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
kernel.ConnectNamedPipe.restype = wintypes.BOOL
kernel.ReadFile.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
                           ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]
kernel.ReadFile.restype = wintypes.BOOL
kernel.CancelIoEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
name = "\\\\.\\pipe\\hmcl-bf656-memory-" + str(uuid.uuid4())
handle = kernel.CreateNamedPipeW(name, 0x00080001, 0x00000008, 1, 8192, 8192, 0, None)
assert handle not in (None, ctypes.c_void_p(-1).value), ctypes.get_last_error()
received: list[bytes] = []
errors: list[BaseException] = []


def receive() -> None:
    try:
        connected = kernel.ConnectNamedPipe(handle, None)
        assert connected or ctypes.get_last_error() == 535, ctypes.get_last_error()
        while not b"".join(received).endswith(b"\n"):
            buffer = ctypes.create_string_buffer(4096)
            count = wintypes.DWORD()
            assert kernel.ReadFile(handle, buffer, len(buffer), ctypes.byref(count), None), ctypes.get_last_error()
            assert count.value
            received.append(buffer.raw[:count.value])
    except BaseException as error:
        errors.append(error)


thread = threading.Thread(target=receive, daemon=True)
thread.start()
try:
    process = subprocess.run([str(EXE), "--dry-run", "--profile", "safe", "--pipe", name],
                             capture_output=True, text=True, timeout=12)
    thread.join(5)
    assert not thread.is_alive(), "Pipe server did not finish"
    assert not errors, errors
    assert process.returncode == 0 and process.stdout == "", (process.returncode, process.stdout)
    result = json.loads(b"".join(received))
    assert result["status"] == "dry_run" and not result["cleanupExecuted"]
    CASES.append({"arguments": ["--dry-run", "--profile", "safe", "--pipe", "<local random pipe>"],
                  "exitCode": 0, "status": result["status"]})
finally:
    kernel.CancelIoEx(handle, None)
    kernel.CloseHandle(handle)
    thread.join(1)

report = {"componentVersion": probe["componentVersion"], "protocolVersion": 1,
          "memoryCleanupExecuted": False, "cases": CASES}
(EXE.parent / "verification.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(f"PASS: {len(CASES)} executable protocol checks, including named-pipe transport; no memory cleanup executed.")
