/* SPDX-License-Identifier: GPL-3.0-only
 * Tests inject fake memory operations: no system memory is cleaned. */
#include "cleaner.h"
#include <stdio.h>
#include <string.h>

static unsigned int failures;
#define CHECK(condition) do { if (!(condition)) { fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #condition); failures++; } } while (0)

typedef struct FAKE_CONTEXT { ULONG calls; ULONG failures; } FAKE_CONTEXT;
static BF656_OPERATION fake_operation(unsigned int operation, void *context)
{
    FAKE_CONTEXT *fake = context;
    BF656_OPERATION result = {TRUE, 0, 0};
    ULONG bit = 1u << operation;
    fake->calls |= bit;
    if (fake->failures & bit) { result.nt_status = (LONG)0xc0000022u; result.win32_error = ERROR_ACCESS_DENIED; }
    return result;
}

int main(void)
{
    BF656_REQUEST request;
    BF656_RESULT result = {0};
    FAKE_CONTEXT fake = {0, 0};
    char json[8192], tiny[8];
    wchar_t *probe[] = {L"cleaner", L"--probe"};
    wchar_t *dry[] = {L"cleaner", L"--dry-run", L"--profile", L"safe"};
    wchar_t *unknown[] = {L"cleaner", L"--clean", L"--profile", L"typo"};
    wchar_t *duplicate[] = {L"cleaner", L"--probe", L"--clean"};
    wchar_t *file[] = {L"cleaner", L"--clean", L"--pipe", L"C:\\result.json"};
    CHECK(bf656_parse(2, probe, &request) && request.mode == BF656_PROBE);
    CHECK(bf656_parse(4, dry, &request) && request.mask == BF656_MASK_SAFE);
    CHECK(!bf656_parse(1, probe, &request));
    CHECK(!bf656_parse(4, unknown, &request));
    CHECK(!bf656_parse(3, duplicate, &request));
    CHECK(!bf656_parse(4, file, &request));
    CHECK(bf656_valid_pipe(BF656_PIPE_PREFIX L"01234567-89ab-cdef-0123-456789abcdef"));
    CHECK(!bf656_valid_pipe(BF656_PIPE_PREFIX L"..\\evil"));
    CHECK(!bf656_valid_pipe(L"\\\\remote\\pipe\\hmcl-bf656-memory-0123456789abcdef0123456789abcdef"));
    result.mode = BF656_CLEAN;
    result.requested_mask = BF656_MASK_SAFE;
    bf656_execute_operations(&result, fake_operation, &fake);
    CHECK(fake.calls == BF656_MASK_SAFE && result.failed_mask == 0 && result.cleanup_executed);
    CHECK(bf656_exit_code(&result) == 0);
    ZeroMemory(&result, sizeof(result));
    fake.calls = 0; fake.failures = 0x81;
    result.mode = BF656_CLEAN; result.requested_mask = BF656_MASK_FULL;
    bf656_execute_operations(&result, fake_operation, &fake);
    CHECK(fake.calls == BF656_MASK_FULL && result.failed_mask == 0x81);
    CHECK(bf656_exit_code(&result) == (BF656_PARTIAL_EXIT | 0x81));
    CHECK(bf656_json(&result, json, sizeof(json)) && strstr(json, "partial_failure") != NULL);
    CHECK(strstr(json, "0xC0000022") != NULL && strstr(json, "\"win32Error\":5") != NULL);
    CHECK(!bf656_json(&result, tiny, sizeof(tiny)));
    result.error = ERROR_ELEVATION_REQUIRED;
    CHECK(bf656_exit_code(&result) == ERROR_ELEVATION_REQUIRED);
    CHECK(bf656_json(&result, json, sizeof(json)) && strstr(json, "\"status\":\"error\"") != NULL);
    CHECK(bf656_parse(4, dry, &request));
    bf656_run(&request, &result);
    CHECK(!result.cleanup_executed && result.failed_mask == 0 && result.error == 0);
    CHECK(result.before_available > 0 && result.after_available > 0);
    if (failures) return 1;
    puts("All component tests passed; no memory cleanup was executed.");
    return 0;
}
