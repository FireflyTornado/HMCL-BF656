[CmdletBinding()]
param([switch]$Test)
$ErrorActionPreference = 'Stop'
$localMsbuild = Join-Path $PSScriptRoot '..\libs\build-tools\VS2026\MSBuild\Current\Bin\MSBuild.exe'
if (Test-Path -LiteralPath $localMsbuild) {
    $msbuild = (Resolve-Path -LiteralPath $localMsbuild).Path
} else {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (-not (Test-Path -LiteralPath $vswhere)) { throw 'MSVC Build Tools with Windows SDK is required.' }
    $msbuild = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -find 'MSBuild\**\Bin\MSBuild.exe' | Select-Object -First 1
    if (-not $msbuild) { throw 'C++ MSBuild installation not found.' }
}
$project = Join-Path $PSScriptRoot 'component.vcxproj'
& $msbuild $project /nologo /m /v:minimal /p:Configuration=Release /p:Platform=x64 "/p:BF656Tests=$($Test.IsPresent.ToString().ToLowerInvariant())"
if ($LASTEXITCODE -ne 0) { throw "Component build failed: $LASTEXITCODE" }
if ($Test) {
    & (Join-Path $PSScriptRoot 'out\x64\bf656-memory-cleaner-tests.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Component tests failed.' }
}
