/* SPDX-License-Identifier: GPL-3.0-only
 * Derived from Henry++'s Mem Reduct src/main.c and src/main.h.
 * Copyright (c) 2011-2026 Henry++ and BF656 contributors.
 * This target intentionally does not link the GUI's incompatible routine SDK.
 */
#include "cleaner.h"
#include <stdio.h>
#include <string.h>
#include <wchar.h>

typedef LONG (NTAPI *BF656_NT_SET)(ULONG, void *, ULONG);
typedef ULONG (WINAPI *BF656_NT_ERROR)(LONG);

/* Native layouts and information classes match the upstream SDK declarations. */
typedef struct BF656_FILE_CACHE {
    ULONG_PTR current_size;
    ULONG_PTR peak_size;
    ULONG page_fault_count;
    ULONG_PTR minimum_working_set;
    ULONG_PTR maximum_working_set;
    ULONG_PTR current_with_transition;
    ULONG_PTR peak_with_transition;
    ULONG transition_repurpose_count;
    ULONG flags;
} BF656_FILE_CACHE;

typedef struct BF656_COMBINE {
    HANDLE handle;
    ULONG_PTR pages_combined;
    ULONG flags;
} BF656_COMBINE;

#ifdef _WIN64
_Static_assert(sizeof(BF656_FILE_CACHE) == 64, "Unexpected native file cache layout");
_Static_assert(offsetof(BF656_FILE_CACHE, minimum_working_set) == 24, "Unexpected alignment");
_Static_assert(sizeof(BF656_COMBINE) == 24, "Unexpected native combine layout");
#endif

typedef struct BF656_NATIVE {
    BF656_NT_SET set;
    BF656_NT_ERROR error;
} BF656_NATIVE;

typedef struct BF656_PRIVILEGES {
    HANDLE token;
    TOKEN_PRIVILEGES previous[2];
    unsigned int changed;
} BF656_PRIVILEGES;

static const char *const operation_names[BF656_OPERATION_COUNT] = {
    "working_sets", "system_file_cache", "low_priority_standby", "standby_list",
    "modified_list", "combine_pages", "registry_cache", "volume_cache"
};

BOOL bf656_valid_pipe(const wchar_t *pipe)
{
    size_t prefix = wcslen(BF656_PIPE_PREFIX);
    size_t length;
    size_t i;
    if (!pipe || wcsncmp(pipe, BF656_PIPE_PREFIX, prefix) != 0) return FALSE;
    length = wcslen(pipe + prefix);
    if (length < 32 || length > 64) return FALSE;
    for (i = 0; i < length; i++) {
        wchar_t c = pipe[prefix + i];
        if (!((c >= L'0' && c <= L'9') || (c >= L'a' && c <= L'f') || c == L'-')) return FALSE;
    }
    return TRUE;
}

BOOL bf656_parse(int argc, wchar_t **argv, BF656_REQUEST *request)
{
    BOOL mode_seen = FALSE, profile_seen = FALSE, pipe_seen = FALSE;
    int i;
    ZeroMemory(request, sizeof(*request));
    request->profile = L"default";
    request->mask = BF656_MASK_DEFAULT;
    for (i = 1; i < argc; i++) {
        if (wcscmp(argv[i], L"--probe") == 0 || wcscmp(argv[i], L"--dry-run") == 0 || wcscmp(argv[i], L"--clean") == 0) {
            if (mode_seen) return FALSE;
            mode_seen = TRUE;
            request->mode = wcscmp(argv[i], L"--probe") == 0 ? BF656_PROBE :
                wcscmp(argv[i], L"--dry-run") == 0 ? BF656_DRY_RUN : BF656_CLEAN;
        } else if (wcscmp(argv[i], L"--profile") == 0) {
            if (profile_seen || ++i >= argc) return FALSE;
            profile_seen = TRUE;
            request->profile = argv[i];
            if (wcscmp(argv[i], L"safe") == 0) request->mask = BF656_MASK_SAFE;
            else if (wcscmp(argv[i], L"default") == 0) request->mask = BF656_MASK_DEFAULT;
            else if (wcscmp(argv[i], L"full") == 0) request->mask = BF656_MASK_FULL;
            else return FALSE;
        } else if (wcscmp(argv[i], L"--pipe") == 0) {
            if (pipe_seen || ++i >= argc || !bf656_valid_pipe(argv[i])) return FALSE;
            pipe_seen = TRUE;
            request->pipe = argv[i];
        } else return FALSE;
    }
    return mode_seen && !(request->mode == BF656_PROBE && profile_seen);
}

void bf656_execute_operations(BF656_RESULT *result, BF656_OPERATION_FN operation, void *context)
{
    unsigned int i;
    for (i = 0; i < BF656_OPERATION_COUNT; i++) {
        ULONG bit = 1u << i;
        if (!(result->requested_mask & bit)) continue;
        result->cleanup_executed = TRUE;
        result->operations[i] = operation(i, context);
        if (!result->operations[i].attempted || result->operations[i].nt_status < 0 || result->operations[i].win32_error != 0)
            result->failed_mask |= bit;
    }
}

DWORD bf656_exit_code(const BF656_RESULT *result)
{
    if (result->error) return result->error;
    if (result->failed_mask) return BF656_PARTIAL_EXIT | result->failed_mask;
    return ERROR_SUCCESS;
}

BOOL bf656_json(const BF656_RESULT *result, char *output, size_t capacity)
{
    const char *status = result->error ? "error" : result->failed_mask ? "partial_failure" :
        result->mode == BF656_PROBE ? "probe" : result->mode == BF656_DRY_RUN ? "dry_run" : "success";
    int count;
    size_t used;
    unsigned int i;
    if (!output || capacity == 0) return FALSE;
    count = _snprintf_s(output, capacity, _TRUNCATE,
        "{\"protocolVersion\":1,\"componentVersion\":\"" BF656_VERSION "\","
        "\"status\":\"%s\",\"exitCode\":%lu,\"requiresElevation\":true,\"elevated\":%s,"
        "\"cleanupExecuted\":%s,\"requestedMask\":%lu,\"failedMask\":%lu,"
        "\"availableBeforeBytes\":%llu,\"availableAfterBytes\":%llu,\"durationMs\":%llu,"
        "\"profiles\":{\"safe\":7,\"default\":231,\"full\":255},\"operations\":[",
        status, bf656_exit_code(result), result->elevated ? "true" : "false",
        result->cleanup_executed ? "true" : "false", result->requested_mask, result->failed_mask,
        result->before_available, result->after_available, result->duration_ms);
    if (count < 0) return FALSE;
    used = (size_t)count;
    for (i = 0; i < BF656_OPERATION_COUNT; i++) {
        const BF656_OPERATION *operation = &result->operations[i];
        count = _snprintf_s(output + used, capacity - used, _TRUNCATE,
            "%s{\"name\":\"%s\",\"requested\":%s,\"attempted\":%s,\"ntStatus\":\"0x%08lX\",\"win32Error\":%lu}",
            i == 0 ? "" : ",", operation_names[i], (result->requested_mask & (1u << i)) ? "true" : "false",
            operation->attempted ? "true" : "false", (ULONG)operation->nt_status, operation->win32_error);
        if (count < 0) return FALSE;
        used += (size_t)count;
    }
    return _snprintf_s(output + used, capacity - used, _TRUNCATE, "]}\n") >= 0;
}

static BOOL is_elevated(void)
{
    HANDLE token = NULL;
    TOKEN_ELEVATION elevation = {0};
    DWORD length = 0;
    BOOL success;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) return FALSE;
    success = GetTokenInformation(token, TokenElevation, &elevation, sizeof(elevation), &length);
    CloseHandle(token);
    return success && elevation.TokenIsElevated != 0;
}

static void restore_privileges(BF656_PRIVILEGES *guard)
{
    while (guard->changed) {
        guard->changed--;
        AdjustTokenPrivileges(guard->token, FALSE, &guard->previous[guard->changed], 0, NULL, NULL);
    }
    if (guard->token) CloseHandle(guard->token);
    guard->token = NULL;
}

static DWORD enable_privileges(BF656_PRIVILEGES *guard)
{
    const wchar_t *const names[2] = {L"SeProfileSingleProcessPrivilege", L"SeIncreaseQuotaPrivilege"};
    unsigned int i;
    ZeroMemory(guard, sizeof(*guard));
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &guard->token)) return GetLastError();
    for (i = 0; i < 2; i++) {
        TOKEN_PRIVILEGES desired = {0};
        DWORD previous_size = sizeof(TOKEN_PRIVILEGES), error;
        desired.PrivilegeCount = 1;
        if (!LookupPrivilegeValueW(NULL, names[i], &desired.Privileges[0].Luid)) return GetLastError();
        desired.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        SetLastError(ERROR_SUCCESS);
        if (!AdjustTokenPrivileges(guard->token, FALSE, &desired, sizeof(TOKEN_PRIVILEGES), &guard->previous[i], &previous_size)) return GetLastError();
        error = GetLastError();
        if (error != ERROR_SUCCESS) return error;
        guard->changed++;
    }
    return ERROR_SUCCESS;
}

/* Same volume-cache operation as upstream, using documented volume enumeration
 * rather than the unavailable routine mount-manager helper. Aggregate failures. */
static DWORD flush_volumes(void)
{
    wchar_t name[MAX_PATH];
    HANDLE enumeration = FindFirstVolumeW(name, MAX_PATH);
    DWORD first_error = ERROR_SUCCESS;
    if (enumeration == INVALID_HANDLE_VALUE) return GetLastError();
    for (;;) {
        size_t length = wcslen(name);
        HANDLE volume;
        if (length && name[length - 1] == L'\\') name[length - 1] = L'\0';
        volume = CreateFileW(name, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
        if (volume == INVALID_HANDLE_VALUE) {
            if (!first_error) first_error = GetLastError();
        } else {
            if (!FlushFileBuffers(volume) && !first_error) first_error = GetLastError();
            CloseHandle(volume);
        }
        if (!FindNextVolumeW(enumeration, name, MAX_PATH)) {
            DWORD error = GetLastError();
            if (error != ERROR_NO_MORE_FILES && !first_error) first_error = error;
            break;
        }
    }
    FindVolumeClose(enumeration);
    return first_error;
}

static BF656_OPERATION native_operation(unsigned int operation, void *context)
{
    BF656_NATIVE *native = context;
    BF656_OPERATION result = {TRUE, 0, ERROR_SUCCESS};
    ULONG command;
    BF656_FILE_CACHE cache = {0};
    BF656_COMBINE combine = {0};
    switch (operation) {
        case 0: command = 2; result.nt_status = native->set(80, &command, sizeof(command)); break;
        case 1:
            cache.minimum_working_set = (ULONG_PTR)-1;
            cache.maximum_working_set = (ULONG_PTR)-1;
            result.nt_status = native->set(81, &cache, sizeof(cache)); break;
        case 2: command = 5; result.nt_status = native->set(80, &command, sizeof(command)); break;
        case 3: command = 4; result.nt_status = native->set(80, &command, sizeof(command)); break;
        case 4: command = 3; result.nt_status = native->set(80, &command, sizeof(command)); break;
        case 5: result.nt_status = native->set(130, &combine, sizeof(combine)); break;
        case 6: result.nt_status = native->set(155, NULL, 0); break;
        case 7: result.win32_error = flush_volumes(); break;
        default: result.win32_error = ERROR_INVALID_PARAMETER; break;
    }
    if (result.nt_status < 0) result.win32_error = native->error(result.nt_status);
    return result;
}

static ULONGLONG available_memory(void)
{
    MEMORYSTATUSEX status = {0};
    status.dwLength = sizeof(status);
    return GlobalMemoryStatusEx(&status) ? status.ullAvailPhys : 0;
}

void bf656_run(const BF656_REQUEST *request, BF656_RESULT *result)
{
    BF656_PRIVILEGES guard = {0};
    BF656_NATIVE native = {0};
    HANDLE mutex = NULL;
    HMODULE module;
    FARPROC set_address, error_address;
    DWORD wait;
    ULONGLONG started = GetTickCount64();
    ZeroMemory(result, sizeof(*result));
    result->mode = request->mode;
    result->requested_mask = request->mode == BF656_PROBE ? 0 : request->mask;
    result->elevated = is_elevated();
    result->before_available = available_memory();
    if (request->mode != BF656_CLEAN) goto finished;
    /* Elevation belongs to the caller, avoiding a detached second process. */
    if (!result->elevated) { result->error = ERROR_ELEVATION_REQUIRED; goto finished; }
    mutex = CreateMutexW(NULL, FALSE, L"Local\\HMCLBF656MemoryCleaner-v1");
    if (!mutex) { result->error = GetLastError(); goto finished; }
    wait = WaitForSingleObject(mutex, 0);
    if (wait != WAIT_OBJECT_0 && wait != WAIT_ABANDONED) {
        result->error = wait == WAIT_TIMEOUT ? ERROR_BUSY : GetLastError();
        CloseHandle(mutex); mutex = NULL; goto finished;
    }
    module = GetModuleHandleW(L"ntdll.dll");
    set_address = module ? GetProcAddress(module, "NtSetSystemInformation") : NULL;
    error_address = module ? GetProcAddress(module, "RtlNtStatusToDosError") : NULL;
    if (!set_address || !error_address) { result->error = ERROR_PROC_NOT_FOUND; goto finished; }
    _Static_assert(sizeof(native.set) == sizeof(set_address), "Function pointer size mismatch");
    memcpy(&native.set, &set_address, sizeof(native.set));
    memcpy(&native.error, &error_address, sizeof(native.error));
    result->error = enable_privileges(&guard);
    if (result->error) goto finished;
    bf656_execute_operations(result, native_operation, &native);
finished:
    restore_privileges(&guard);
    if (mutex) { ReleaseMutex(mutex); CloseHandle(mutex); }
    result->after_available = available_memory();
    result->duration_ms = GetTickCount64() - started;
}
