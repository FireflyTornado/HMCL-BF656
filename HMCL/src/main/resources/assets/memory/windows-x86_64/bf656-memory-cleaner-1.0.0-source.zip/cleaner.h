/* SPDX-License-Identifier: GPL-3.0-only
 * Mem Reduct-derived BF656 component. See SOURCE.md for upstream attribution.
 */
#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stddef.h>

#define BF656_PROTOCOL 1
#define BF656_VERSION "1.0.0"
#define BF656_PIPE_PREFIX L"\\\\.\\pipe\\hmcl-bf656-memory-"
#define BF656_OPERATION_COUNT 8
#define BF656_MASK_SAFE 0x07u
#define BF656_MASK_DEFAULT 0xe7u
#define BF656_MASK_FULL 0xffu
#define BF656_PARTIAL_EXIT 0x10000u

typedef enum BF656_MODE { BF656_PROBE, BF656_DRY_RUN, BF656_CLEAN } BF656_MODE;

typedef struct BF656_REQUEST {
    BF656_MODE mode;
    ULONG mask;
    const wchar_t *profile;
    const wchar_t *pipe;
} BF656_REQUEST;

typedef struct BF656_OPERATION {
    BOOL attempted;
    LONG nt_status;
    DWORD win32_error;
} BF656_OPERATION;

typedef struct BF656_RESULT {
    BF656_MODE mode;
    ULONG requested_mask;
    ULONG failed_mask;
    BOOL elevated;
    BOOL cleanup_executed;
    DWORD error;
    ULONGLONG before_available;
    ULONGLONG after_available;
    ULONGLONG duration_ms;
    BF656_OPERATION operations[BF656_OPERATION_COUNT];
} BF656_RESULT;

/* The injected operation callback makes failure reporting testable without cleaning RAM. */
typedef BF656_OPERATION (*BF656_OPERATION_FN)(unsigned int operation, void *context);

BOOL bf656_valid_pipe(const wchar_t *pipe);
BOOL bf656_parse(int argc, wchar_t **argv, BF656_REQUEST *request);
void bf656_execute_operations(BF656_RESULT *result, BF656_OPERATION_FN operation, void *context);
DWORD bf656_exit_code(const BF656_RESULT *result);
BOOL bf656_json(const BF656_RESULT *result, char *output, size_t capacity);
void bf656_run(const BF656_REQUEST *request, BF656_RESULT *result);
